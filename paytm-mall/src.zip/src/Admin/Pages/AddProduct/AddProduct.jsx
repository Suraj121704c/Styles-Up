import React from 'react'

const AddProduct = () => {
  return (
    <div>AddProduct</div>
  )
}

export default AddProduct