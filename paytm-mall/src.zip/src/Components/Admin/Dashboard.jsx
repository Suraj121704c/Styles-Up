import ManageUsers from './ManageUsers';

const Dashboard = () => {
  return <ManageUsers/>
}
export default Dashboard;
