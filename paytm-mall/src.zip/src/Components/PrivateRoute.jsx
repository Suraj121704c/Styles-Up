import React from 'react'

export const PrivateRoute = () => {
  return (
    <div>PrivateRoute</div>
  )
}
