import React from 'react'
import Admin_Sidebar from "../Components/Admin/Admin_Sidebar"

export const Admin = () => {
  return (
    <div>
       <Admin_Sidebar/>
    </div>
  )
}
